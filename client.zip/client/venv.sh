#!/bin/bash
echo "Setting up venv"
# Setting up venv
virtualenv venv
source ./venv/bin/activate
# Installing dependencies
pip install -r requirements.txt
deactivate

