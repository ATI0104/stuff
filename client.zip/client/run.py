#!/usr/bin/python3
import random
import subprocess
import sys
import time
import psutil
import os
import json
from flask import Flask, request, jsonify

browser = "/usr/bin/google-chrome-stable"  # TODO Change this to your browser
# TODO Change this to your output device (you can find it by running xrandr)
output_device = "HDMI-1"
port = 2345  # Port where the program listens to update requests

app = Flask(__name__)
# Define the command to set "Broadcast RGB" to "Full"
xrandr_command = f'xrandr --output {output_device} --set "Broadcast RGB" "Full"'
#xrandr_command='exit 0' # for testing purposes
# Execute the xrandr command to set RGB mode to Full
r = subprocess.Popen(xrandr_command, shell=True)
#Checking if we have a GUI (to prevent it from running through ssh)
while r.poll() is None:
    pass
if r.poll() != 0:
    exit(r.poll())
with open('data.json') as json_file:
    data = json.load(json_file)
# Define the command to open Chromium in kiosk mode
chromium_command = f'{browser} -kiosk -fullscreen http://{data["url"]}/{data["id"]}'


def start_chromium():
    global chromium
    chromium = subprocess.Popen(chromium_command, shell=True)
# Function to stop Chromium


def stop_chromium():
    chromium.terminate()


@app.get("/UPDATE_RUNNER")
def update():
    try:
        global chromium_command
        url = request.args.get('webserver')
        id = request.args.get('identifier')
        if url is None or id is None:
            return "ERROR, webserver or identifier is missing", 400
        with open('data.json', 'w') as f:
            # Save data for next boot
            json.dump({"url": url, "id": id}, f)
        stop_chromium()
        chromium_command = f'{browser} -kiosk -fullscreen http://{url}/{id}'
        start_chromium()
        return "OK", 200
    except Exception as e:
        return str(e), 404

if __name__ == "__main__":
    print("Intializing Service...",file=sys.stderr) # Some timeout needed for ubuntu to init everything
    for i in range(10):
        s=10-i
        if i % 2:
            print(f"Starting in {s} seconds.",file=sys.stderr)
        time.sleep(1)
    start_chromium()
    app.run(host='0.0.0.0', port=port)
