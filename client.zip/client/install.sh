#!/bin/bash
USERNAME="maxnet"
CWD=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" &> /dev/null && pwd)
cd "${CWD}" #Redundant command but IDC
# Ensure the script is run as root
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root" 1>&2
   exit 1
fi
sudo chmod -R a+x ./
echo "Installing required packages and creating a virtual environment..."
sudo apt update
sudo apt install python3-pip python3-virtualenv -y
sudo -u ${USERNAME} ./venv.sh
echo "Setting folder permissions"
sudo chmod -R a+x ./

# Define the service file content
SERVICE_FILE_CONTENT="[Unit]
Description=LED Screen Client service
After=graphical.target

[Service]
User=${USERNAME}
Environment="DISPLAY=:0"
WorkingDirectory=${CWD}
Type=exec
Restart=on-failure
ExecStart=${CWD}/run.sh

[Install]
WantedBy=default.target"

# Define the service file path
SERVICE_PATH="/etc/systemd/system/ledclient.service"

# Create the service file
echo "$SERVICE_FILE_CONTENT" > "$SERVICE_PATH"

# Reload systemd to recognize the new service
systemctl daemon-reload

# Enable and start the service
systemctl enable ledclient
sed -i 's/#WaylandEnable=false/WaylandEnable=false/' /etc/gdm3/custom.conf
systemctl restart gdm
echo "Service has been created and should run on next boot"
echo "To start it, now run:"
echo "sudo systemctl start ledclient"

