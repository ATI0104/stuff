#!/bin/bash
while ! xset q &>/dev/null; do
    sleep 1
done
xhost +SI:localuser:maxnet
source ./venv/bin/activate
python3 run.py
deactivate
